# A somehow `awesome` Project Build with `TypeORM` By Sean Baraka

Steps to run this project:

1. Run `npm i` command.
2. Setup database settings inside `ormconfig.json` file.
3. Run `npm start` command.
4. And you are good to go.
5. Like thats just it, nothing more. Do not even read no. 6.
6. Do not read no. 7 this is just the end there is nothing more you have to do.
7. Wait for further documentation on the `api` endponts. Coming soon..