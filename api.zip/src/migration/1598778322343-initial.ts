import {MigrationInterface, QueryRunner} from "typeorm";

export class initial1598778322343 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
